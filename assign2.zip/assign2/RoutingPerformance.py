#!/usr/bin/env python3

from collections import defaultdict, deque
import math
import random
import sys

class Topology:
    def __init__(self, TOPOLOGY_FILE):
        self.links   = defaultdict(set) # adjacency list representation of the network
        self.d_props = {}               # stores propagation delay of each link
        self.caps    = {}               # stores capacity of each link
        self.loads   = {}               # stores packets on each link
        with open(TOPOLOGY_FILE) as file:
            for line in file.readlines():
                node1, node2, d_prop, cap = line.split()
                d_prop, cap = int(d_prop), int(cap)
                self.links[node1].add(node2)
                self.links[node2].add(node1)
                self.d_props[tuple(sorted([node1, node2]))] = d_prop
                self.caps[tuple(sorted([node1, node2]))]    = cap
                self.loads[tuple(sorted([node1, node2]))]   = deque()

    def get_paths(self, pred, node):
        if not pred[node]:
            return [[node]]
        paths = []
        for pred_node in pred[node]:
            for pred_path in self.get_paths(pred, pred_node):
                paths.append(pred_path + [node])
        return paths
    
    def dijkstra(self, ROUTING_SCHEME, link):
        source, sink = link
        dist, dist[source] = {node:math.inf for node in self.links}, 0
        pred = {node:set() for node in self.links}
        v_set = set(self.links.keys())
        while v_set:
            min_dist = math.inf
            for v in v_set:
                if dist[v] < min_dist:
                    min_dist, v_min = dist[v], v
            for w in self.links[v_min]:
                if w in v_set:
                    if ROUTING_SCHEME == "SHP":
                        new_dist = dist[v_min] + 1
                    elif ROUTING_SCHEME == "SDP":
                        new_dist = dist[v_min] + self.d_props[tuple(sorted([v_min, w]))]
                    else:   # "LLP"
                        new_dist = dist[v_min] + len(self.loads[tuple(sorted([v_min, w]))])
                    if new_dist < dist[w]:
                        dist[w], pred[w] = new_dist, set([v_min])
                    elif new_dist == dist[w]:
                        pred[w].add(v_min)
            v_set.remove(v_min)
        path, sublinks = random.choice(self.get_paths(pred, sink)), []
        for i in range(len(path) - 1):
            sublinks += [tuple(sorted([path[i], path[i + 1]]))]
        return sublinks

def main():
    if len(sys.argv) < 6:
        print("Usage: python RoutingPerformance.py <NETWORK_SCHEME> <ROUTING_SCHEME> <TOPOLOGY_FILE> <WORKLOAD_FILE> <PACKET_RATE>")
        sys.exit(-1)
    NETWORK_SCHEME, ROUTING_SCHEME, TOPOLOGY_FILE, WORKLOAD_FILE, PACKET_RATE = sys.argv[1:]
    PACKET_RATE = int(PACKET_RATE)
    
    t = Topology(TOPOLOGY_FILE)
    vreqs = []
    with open(WORKLOAD_FILE) as file:
        for line in file.readlines():
            t_estab, node1, node2, dur = line.split()
            t_estab, dur = float(t_estab), float(dur)
            vreqs += [(t_estab, dur, (node1, node2))]
    vreqs.sort()    # sort ascending based on connection establishment time
    vreqs = deque(vreqs)

    total_vreqs = len(vreqs)    # total number of virtual connection requests
    total_packs = 0             # total number of packets
    total_block_packs = 0       # total number of blocked packets
    total_circs = 0             # total number of successfully routed circuits
    total_hops = 0              # total number of hops of successfully routed circuits
    total_d_prop = 0            # total propagation delay of successfully routed circuits
    d_e2e = 1 / PACKET_RATE     # end to end delay
    q_packs = deque()           # packets not yet loaded into the links
    while 1:
        # get nearest event time ()
        time = min([vreqs[0][0] for _ in range(1) if len(vreqs) > 0]
                   + [q_packs[0][0] for _ in range(1) if len(q_packs) > 0]
                   + [t.loads[link][0] for link in t.loads if len(t.loads[link]) > 0]
                   + [math.inf])
        if time == math.inf:    # no event left
            break
        # while there is a virtual connection request that starts at time
        while len(vreqs) > 0 and vreqs[0][0] == time:
            l_packs = list(q_packs)
            t_estab, dur, link = vreqs.popleft()
            n_packs = int(dur * PACKET_RATE)
            total_packs += n_packs
            if NETWORK_SCHEME == "CIRCUIT":
                t_in, t_out = t_estab, t_estab + dur
                l_packs += [(float("%.6f" % t_in), float("%.6f" % t_out), link, n_packs)]
            else:   # "PACKET"
                t_in, t_out = t_estab, t_estab + d_e2e
                for _ in range(n_packs):
                    l_packs += [(float("%.6f" % t_in), float("%.6f" % t_out), link, 1)]
                    t_in = t_out
                    t_out += d_e2e
            l_packs.sort()  # sort ascending based on the time the packet needs to be deployed into the link
            q_packs = deque(l_packs)
        # while there is a packet that should exit a link at time
        for link in t.loads:
            while len(t.loads[link]) > 0 and t.loads[link][0] == time:
                t.loads[link].popleft()
        # while there is a packet that should be deployed to a link at time
        while len(q_packs) > 0 and q_packs[0][0] == time:
            t_in, t_out, link, n_packs = q_packs.popleft()
            sublinks = t.dijkstra(ROUTING_SCHEME, link)
            is_blocked = False
            for link in sublinks:
                if len(t.loads[link]) + 1 > t.caps[link]:
                    is_blocked = True
                    break
            if not is_blocked:
                total_circs += 1
                total_hops += len(sublinks)
                for link in sublinks:
                    t.loads[link].append(t_out)
                    if NETWORK_SCHEME == "CIRCUIT":
                        # since t_out isn't guaranteed to be appended in ascending order
                        temp_load = list(t.loads[link])
                        temp_load.sort()
                        t.loads[link] = deque(temp_load)
                    total_d_prop += t.d_props[link]
            else:
                total_block_packs += n_packs

    print("total number of virtual circuit requests:", total_vreqs)
    print("total number of packets:", total_packs)
    print("number of successfully routed packets:", total_packs - total_block_packs)
    print("percentage of successfully routed packets: {0:.2f}".format((total_packs - total_block_packs) * 100 / total_packs))
    print("number of blocked packets:", total_block_packs)
    print("percentage of blocked packets: {0:.2f}".format(total_block_packs * 100 / total_packs))
    print("average number of hops per circuit: {0:.2f}".format(total_hops / total_circs))
    print("average cumulative propagation delay per circuit: {0:.2f}".format(total_d_prop / total_circs))

if __name__ == "__main__":
    main()
