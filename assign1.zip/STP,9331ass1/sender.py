import time
import socket
import random
import sys
import os
import threading
import pickle
from STP import STP_Segment

class RepeatingTimer(object):
    def __init__(self, interval):
        self.interval = interval
        self.timer = None
        self.started = False

    def cancel(self):
        self.started = False
        self.timer = None

    def start(self):
        assert(not self.started)
        self.timer = time.time()
        self.started = True

    def restart(self):
        if self.started:
            self.cancel()
        self.start()

    def expire(self):
        if self.started and time.time() - self.timer >= self.interval:
            return True
        return False



class 

    def __init__(self, receiver_host_ip, receiver_port, filename, MWS, MSS, timeout_ms, pdrop, seed):
        self.receiver_host_ip = receiver_host_ip
        try:
            self.receiver_port = int(receiver_port)
            if self.receiver_port <=1024 or self.receiver_port >= 65536:
                raise ValueError
            # check if file exists or not
            if not os.path.exists(filename):
                raise ValueError
            self.filename = filename
            self.MWS = int(MWS)
            if self.MWS < 0: raise ValueError
            self.MSS = int(MSS)
            if self.MSS < 0:
                raise ValueError
            if self.MSS > self.MWS:
                self.MSS = self.MWS

            self.timeout = int(timeout_ms)/1000
            if self.timeout < 0:
                raise ValueError
            self.pdrop = float(pdrop) # 0-1
            if self.pdrop < 0 or self.pdrop >1:
                raise ValueError
            self.seed = int(seed)
        except ValueError:
            print('invalid parameter!')
            print('python3 sender.py receiver_host_ip receiver_port(1025-65535) filename MWS(1-Inf) MSS(1-Inf) timeout(1-Inf) pdrop(0-1) seed')
            sys.exit()

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.FSM = 'IDLE' # "IDLE" 'TWH' 'DATA' 'FST'
        self.Fisn = None
        self.lock = threading.Semaphore()

        self.amount_byte = 0
        self.amount_seg = 0
        self.retransmit_packet = 0
        self.dropped = 0
        self.dup_acks = 0


    def get_flags(self, syn, ack, fin):
        flags = ''
        if syn:
            flags += 'S'
        if ack:
            flags += 'A'
        if fin:
            flags += 'F'
        if flags == '':
            flags = 'D'
        return flags

    def send(self, sequence, acknowledge, window, syn, ack, fin, payload):
        packet = STP_Segment(sequence, acknowledge, window, syn, ack, fin, payload)
        packet = pickle.dumps(packet)
        flags = self.get_flags(syn, ack, fin)
        if flags == 'D':
            if random.random() < self.pdrop:
                self.dropped += 1
                print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('drop', (time.time()-self.beginTime) * 1000, flags, sequence, len(payload), acknowledge), file=self.log)
            else:
                self.socket.sendto(packet, (self.receiver_host_ip, self.receiver_port))
                print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('snd', (time.time()-self.beginTime) * 1000, flags, sequence, len(payload), acknowledge), file=self.log)
        else:
            self.socket.sendto(packet, (self.receiver_host_ip, self.receiver_port))
            print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('snd', (time.time()-self.beginTime) * 1000, flags, sequence, len(payload), acknowledge), file=self.log)


    def receive(self):
        packet, addr = self.socket.recvfrom(1024)
        while addr != (self.receiver_host_ip, self.receiver_port):
            packet, addr = self.socket.recvfrom(1024)
        packet = pickle.loads(packet)
        flags = self.get_flags(packet.syn, packet.ack, packet.fin)
        print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('rcv', (time.time()-self.beginTime) * 1000, flags, packet.sequence, len(packet.payload), packet.acknowledge), file=self.log)

        return packet

    def TWH_is_good_ack(self, packet):
        if packet.acknowledge == self.Cisn+1 and packet.syn == True and packet.ack == True and packet.fin == False and packet.payload == '':
            return True
        return False

    def TWH(self):
        self.Cisn = random.randint(0, 1024)
        self.beginTime = time.time()
        self.send(self.Cisn, 0, self.MSS+126, True, False, False, '')

        packet = self.receive()
        if self.TWH_is_good_ack(packet):
            self.Sisn = packet.sequence
            self.send(self.Cisn+1, self.Sisn+1, self.MSS+126, False, True, False,'')
            self.FSM = 'DATA'

    def sending_thread(self):
        print('sending_thread start')
        while self.FSM == 'DATA':
            self.lock.acquire()
            if self.LastByteSent - self.LastByteAcked + self.MSS <= self.MWS:
                self.send(self.NextSeqNum, 0, self.MSS + 126, False, False, False, self.all_packets[self.NextSeqNum])
                self.LastByteSent = self.NextSeqNum
                self.lock.release()
                self.NextSeqNum += len(self.all_packets[self.NextSeqNum])
                if not self.timer.started:
                    self.timer.start()
                if self.NextSeqNum not in self.all_packets:
                    self.Fisn = self.NextSeqNum
                    break

            else:
                self.lock.release()
                #pass
                time.sleep(0.001)
        print('sending_thread done')

    def fast_detect(self, acknowledge):
        if acknowledge in self.received_acks:
            self.dup_acks += 1
            self.received_acks[acknowledge] += 1
            if self.received_acks[acknowledge] >= 3:
                self.received_acks[acknowledge] = 0
                self.send(acknowledge, 0, self.MSS + 126, False, False, False, self.all_packets[acknowledge])
                self.retransmit_packet += 1
                #print('fast', acknowledge)
        else:
            self.received_acks[acknowledge] = 0

    def receiving_thread(self):
        self.received_acks = {}
        all_sequence = sorted(self.all_packets.keys())
        print('recv start')
        while self.FSM == 'DATA':
            packet = self.receive()
            if packet.ack != True:
                continue
            if self.Fisn is not None and packet.acknowledge == self.Fisn:
                # self.timer.cancel()
                self.FSM = 'FST'
                break
            self.fast_detect(packet.acknowledge)

            temp = all_sequence.index(packet.acknowledge) - 1
            if temp != -1:
                new_lastbyteacked = all_sequence[temp]
                if new_lastbyteacked > self.LastByteAcked:
                    self.lock.acquire()
                    self.LastByteAcked = new_lastbyteacked
                    self.lock.release()
                    if self.LastByteAcked < self.LastByteSent:
                        self.timer.restart()
        print('recv start')


    def timeout_callback(self):
        print('timer start')
        while self.FSM == 'DATA':
            time.sleep(0.001)
            if self.timer.expire():
                # self.lock.acquire()
                if self.LastByteAcked in self.all_packets:
                    temp_sequence = self.LastByteAcked + len(self.all_packets[self.LastByteAcked])
                else:
                    temp_sequence = self.LastByteAcked + 1

                self.send(temp_sequence, 0, self.MSS + 126, False, False, False, self.all_packets[temp_sequence])
                self.retransmit_packet += 1
                self.timer.restart()
        print('timer start')

    def DATA(self):
        self.all_packets = {}
        with open(self.filename, 'rb') as f:
            raw_data = f.read().decode('utf-8')
            self.amount_byte = len(raw_data)
            for i in range(0, len(raw_data), self.MSS):
                self.all_packets[self.Cisn+1+i] = raw_data[i:i+self.MSS]
        self.amount_seg = len(self.all_packets)
        self.LastByteAcked = self.Cisn
        self.LastByteSent = self.Cisn
        self.NextSeqNum = self.Cisn + 1
        self.timer = RepeatingTimer(self.timeout)
        if self.all_packets != {}:
            handlers = []
            handlers.append(threading.Thread(target=self.sending_thread))
            handlers.append(threading.Thread(target=self.receiving_thread))
            handlers.append(threading.Thread(target=self.timeout_callback))
            for handle in handlers:
                handle.start()
            for handle in handlers:
                handle.join()
        self.FSM = 'FST'

    def FST_is_good_finack(self, packet):
        if packet.acknowledge == self.Fisn + 1 and packet.syn == False and packet.ack == True and packet.fin == True:
            return True
        return False


    def FST(self):
        if self.Fisn is None:
            self.Fisn = self.Cisn + 1
        self.send(self.Fisn, 0, self.MSS+126, False, False, True, '')
        packet = self.receive()
        if self.FST_is_good_finack(packet):
            self.send(self.Fisn+1, packet.sequence+1, self.MSS+126, False, True, False,'')
            self.FSM = 'IDLE'

    def sendfile(self):
        self.FSM = 'TWH'
        random.seed(self.seed)
        self.log = open('Sender_log.txt', "w")
        while self.FSM != 'IDLE':
            if self.FSM == 'TWH':
                self.TWH()
            elif self.FSM == 'DATA':
                self.DATA()
            elif self.FSM == 'FST':
                self.FST()
            elif self.FSM == 'IDLE':
                break
            else:
                assert(False)
        print('Amount of (original) Data Transferred (in bytes):', self.amount_byte, file=self.log)
        print('Number of Data Segments Sent:', self.amount_seg, file=self.log)
        print('Number of (all) Packets Dropped:', self.dropped, file=self.log)
        print('Number of Retransmitted Segments:', self.retransmit_packet, file=self.log)
        print('Number of Duplicate Acknowledgements received:', self.dup_acks, file=self.log)
        self.log.close()
        print('done')


if len(sys.argv) != 9:
    print('python3 sender.py receiver_host_ip receiver_port(1025-65535) filename MWS(1-Inf) MSS(1-Inf) timeout(1-Inf) pdrop(0-1) seed')
    sys.exit()


receiver_host_ip = sys.argv[1]
receiver_port = sys.argv[2]
filename = sys.argv[3]
MWS = sys.argv[4]
MSS = sys.argv[5]
timeout_ms = sys.argv[6]
pdrop = sys.argv[7]
seed = sys.argv[8]

# receiver_host_ip = '127.0.0.1'
# receiver_port = '12345'
# filename = 'test3.txt'
# MWS = '500'
# MSS = '10'
# timeout_ms = '2'
# pdrop = '0.6'
# seed = '300'

sender = Sender(receiver_host_ip, receiver_port, filename, MWS, MSS, timeout_ms, pdrop, seed)
sender.sendfile()











