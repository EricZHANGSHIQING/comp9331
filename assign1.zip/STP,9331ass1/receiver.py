import time
import socket
import random
import sys
import os
from STP import STP_Segment
import pickle

class Receiver(object):
    def __init__(self, receiver_port, filename):
        try:
            self.receiver_port = int(receiver_port)
            if self.receiver_port < 1025 or self.receiver_port > 65535:
                raise ValueError
        except ValueError:
            print('invalid parameter!')
            print('python3 receiver.py receiver_port(1025-65535) filename')
            sys.exit()
        self.filename = filename

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.FSM = 'IDLE' # 'IDLE' 'TWH' 'DATA' 'FST'
        self.receiver_buffsize = 1024
        self.sender_addr = None
        self.beginTime = None

        self.amount_byte = 0
        self.amount_seg = 0
        self.dup_acks = 0

    def get_flags(self, syn, ack, fin):
        flags = ''
        if syn:
            flags += 'S'
        if ack:
            flags += 'A'
        if fin:
            flags += 'F'
        if flags == '':
            flags = 'D'
        return flags

    def send(self, sequence, acknowledge, window, syn, ack, fin, payload):
        packet = STP_Segment(sequence, acknowledge, window, syn, ack, fin, payload)
        flags = self.get_flags(syn, ack, fin)
        packet = pickle.dumps(packet)
        self.socket.sendto(packet, self.sender_addr)
        print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('snd', (time.time()-self.beginTime) * 1000, flags, sequence, len(payload), acknowledge), file=self.log)

    def receive(self):
        packet, addr = self.socket.recvfrom(self.receiver_buffsize)
        if self.beginTime is None:
            self.beginTime = time.time()

        if self.sender_addr is not None:
            while addr != self.sender_addr:
                packet, addr = self.socket.recvfrom(self.receiver_buffsize)
        packet = pickle.loads(packet)
        flags = self.get_flags(packet.syn, packet.ack, packet.fin)
        print('{:<5} {:<7.2f} {:<2} {:<7} {:<4} {:<7}'.format('rcv', (time.time()-self.beginTime) * 1000, flags, packet.sequence, len(packet.payload), packet.acknowledge), file=self.log)
        if self.sender_addr is None:
            self.sender_addr = addr
        return packet

    def TWH_is_good_ack(self, packet):
        if packet.acknowledge == self.Sisn+1 and packet.syn == False and packet.ack == True and packet.fin == False and packet.payload == '':
            return True
        return False


    def TWH(self):
        packet = self.receive()
        if packet.syn != True:
            return
        self.Sisn = random.randint(0, 1024)
        self.Cisn = packet.sequence

        self.receiver_buffsize = packet.window if packet.window > self.receiver_buffsize else self.receiver_buffsize

        self.send(self.Sisn, self.Cisn+1, 0, True, True, False, '')

        packet = self.receive()
        if self.TWH_is_good_ack(packet):
            self.receiver_buffsize = packet.window if packet.window > self.receiver_buffsize else self.receiver_buffsize
            self.NextSeqNum = self.Cisn + 1
            self.FSM = 'DATA'

    def check_inorder(self, packet, all_packets):
        if self.NextSeqNum == packet.sequence:
            self.NextSeqNum += len(packet.payload)
            while self.NextSeqNum in all_packets:
                self.NextSeqNum += len(all_packets[self.NextSeqNum])

    def write_to_file(self, all_packets):
        with open(self.filename, 'w') as f:
            self.amount_seg = len(all_packets)
            all_packets = sorted(all_packets.items())
            all_packets = [x[1] for x in all_packets]
            all_packets = ''.join(all_packets)
            self.amount_byte = len(all_packets)
            f.write(all_packets)

    def DATA(self):
        all_packets = {}

        while True:
            packet = self.receive()
            if packet.fin == True:
                self.write_to_file(all_packets)
                self.CFsn = packet.sequence
                break

            if packet.sequence not in all_packets:
                all_packets[packet.sequence] = packet.payload
            else:
                self.dup_acks += 1
            self.check_inorder(packet, all_packets)

            self.send(self.Sisn, self.NextSeqNum, 0, False, True, False, '')


        self.FSM = 'FST'

    def FST(self):

        self.SFsn = self.Sisn + 1
        self.send(self.SFsn, self.CFsn + 1, 0, False, True, True, '')
        packet = self.receive()
        if packet.acknowledge == self.SFsn + 1 and packet.syn == False and packet.ack == True and packet.fin == False:
            self.FSM = 'IDLE'


    def receivefile(self):
        self.socket.bind(('', self.receiver_port))
        self.FSM = 'TWH'
        self.log = open('Receiver_log.txt', 'w')
        while self.FSM != 'IDLE':
            if self.FSM == 'TWH':
                self.TWH()
            elif self.FSM == 'DATA':
                self.DATA()
            elif self.FSM == 'FST':
                self.FST()
            elif self.FSM == 'IDLE':
                break
            else:
                assert(False)
        print('Amount of (original) Data Received (in bytes):', self.amount_byte,file=self.log)
        print('Number of (original) Data Segments Received:',self.amount_seg, file=self.log)
        print('Number of duplicate segments received:',self.dup_acks, file=self.log)
        self.log.close()
        print('done')


if len(sys.argv) != 3:
    print('python3 receiver.py receiver_port(1025-65535) filename')
    sys.exit()

receiver_port = sys.argv[1]
filename = sys.argv[2]

# receiver_port = '12345'
# filename = 'file2.txt'

receiver = Receiver(receiver_port, filename)

receiver.receivefile()
