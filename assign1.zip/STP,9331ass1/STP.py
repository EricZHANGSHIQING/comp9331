

class STP_Segment(object):
    def __init__(self, sequence, acknowledge, window, syn, ack, fin, payload):
        self.sequence = sequence
        self.acknowledge = acknowledge
        self.window = window
        self.syn = syn
        self.ack = ack
        self.fin = fin
        self.payload = payload


